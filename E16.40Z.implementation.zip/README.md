Cette archive contient les éléments permettant de reproduire les solutions techniques pour le projet 40Z sélectionnées par l'équipe E16 à savoir la suite ELK appliquée à l'exploitation de journaux d’application.

Lien github de la branche de l'équipe E16 : https://github.com/prodageo/mniproj2020b-2020a40z/tree/E16/implementation/E16
